package com.example.newfragments
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.thirdactivity)
        val btnStartOneAnotherActivity=findViewById<Button>(R.id.bt2)
        btnStartOneAnotherActivity.setOnClickListener {
            val intent = Intent(this, FourthActivity::class.java)
            // start your next activity
            startActivity(intent)
        }

    }

}